import time
import random
from slap_jack_deck import player_deck, computer_deck
from graphics import player_cardDisplay, computer_cardDisplay, slap_burnDisplay, dealCards, collectDeck, the_outcome, burn_cardDisplay

def if_notJack(deck, graphics_func, center_deck):

    image_card = deck[0][1]

    text_card = deck[0][2]

    popped_card = deck.pop(0)

    center_deck.append(popped_card)

    graphics_func(image_card)

    print('The', text_card, 'was played.')

def else_Jack(deck, graphics_func, center_deck):
    
    image_card = deck[0][1]

    jack_text_card = deck[0][2]

    popped_card = deck.pop(0)

    center_deck.append(popped_card)

    graphics_func(image_card)

    print('The ' + jack_text_card + ' was played! SLAP!')

    return image_card

def collect_middleDeck(deck, center_deck):

    num_of_cards = len(center_deck)

    deck = deck + center_deck

    random.shuffle(deck)

    center_deck.clear()

    return deck, num_of_cards

def who_Won():

    start_time = time.time()

    user_input = input()

    if user_input == 's':

        end_time = time.time()

        total_time = end_time - start_time

        return total_time

    else:

        print("You need to press the 's' key to SLAP, friend.")

        return 10000

def game_Flow():
    
    center_deck = []

    temp_player_deck = player_deck

    temp_computer_deck = computer_deck

    user_difficulty = input('\nWould you like to play in Easy or Hard mode?\n')

    user_difficulty = user_difficulty.lower()

    if user_difficulty == 'easy':

        print('\nEasy mode it is! Sit back, relax, and ENJOY!\n')

        random_num = random.uniform(1.1, 2)

    elif user_difficulty == 'hard':

        print('\nOooooh HARD mode!! Sit up, focus, and make your ancestors proud!\n')

        random_num = random.uniform(0.5, 1.0)

    else:

        print('\nYou put in an invalid difficulty. I am, therefore, making you play in EXPERT mode! Have fun, and be fast!\n')

        random_num = random.uniform(0.1, 0.4)

    print("Begin by pressing the 'Enter' button. Have fun!\n")
    
    while (len(temp_player_deck) < 52 and len(temp_computer_deck) < 52):

        if len(temp_player_deck) == 0:

            the_outcome('you_lose.gif', 'red_background.gif', 0, -100)

            print('\nYou ran out of cards! You are the loser!\n')

            print('If you would like to redeem yourself, please call me through your terminal window.\n')

            input()

            break

        else:

            deal_input = input()

            if deal_input == 's':

                burn_pop = temp_player_deck.pop(0)

                center_deck.append(burn_pop)

                print('BURN! You lost the', burn_pop[2])

                slap_burnDisplay('burn.gif')

                burn_cardDisplay(burn_pop[1])

            else:

                if temp_player_deck[0][0] != "Jack":

                    if_notJack(temp_player_deck, player_cardDisplay, center_deck)
                
                else:

                    the_jack = else_Jack(temp_player_deck, player_cardDisplay, center_deck)

                    total_time = who_Won()

                    if total_time > random_num:

                        slap_burnDisplay('computer_slap.gif')

                        temp_computer_deck, num_of_cards = collect_middleDeck(temp_computer_deck, center_deck)

                        collectDeck(the_jack, 'red_background.gif', 90)

                        print('The computer collected', num_of_cards, 'cards!')

                    else:

                        slap_burnDisplay('hand_slap.gif')

                        temp_player_deck, num_of_cards = collect_middleDeck(temp_player_deck, center_deck)

                        collectDeck(the_jack, 'red_background.gif', 270)

                        print('You collected', num_of_cards, 'cards! Now you have', len(temp_player_deck), 'cards!')
                
        if len(temp_computer_deck) == 0:

            the_outcome('you_win.gif', 'red_background.gif', 0, 100)

            print('\nThe computer ran out of cards! You are the winner!\n')

            print('You shall now reap the feelings of VICTORY! Play again? Please call me through your terminal window :)\n')

            input()

            break

        else:
            
            if temp_computer_deck[0][0] != "Jack":

                if_notJack(temp_computer_deck, computer_cardDisplay, center_deck)
                
            else:

                the_jack = else_Jack(temp_computer_deck, computer_cardDisplay, center_deck)
                
                total_time = who_Won()

                if total_time > random_num:

                    slap_burnDisplay('computer_slap.gif')

                    temp_computer_deck, num_of_cards = collect_middleDeck(temp_computer_deck, center_deck)

                    collectDeck(the_jack, 'red_background.gif', 90)

                    print('The computer collected', num_of_cards, 'cards!')

                else:

                    slap_burnDisplay('hand_slap.gif')

                    temp_player_deck, num_of_cards = collect_middleDeck(temp_player_deck, center_deck)

                    collectDeck(the_jack, 'red_background.gif', 270)

                    print('You collected', num_of_cards, 'cards! Now you have', len(temp_player_deck), 'cards!')

    if len(temp_computer_deck) == 52:

        the_outcome('you_lose.gif', 'red_background.gif', 0, -100)

        print("The computer now has all 52 cards. Sorry but, THE COMPUTER WON!!")

        input()

    elif len(temp_player_deck) == 52:

        the_outcome('you_win.gif', 'red_background.gif', 0, -100)

        print('YOU COLLECTED ALL 52 CARDS!! YOU WON')

        input()