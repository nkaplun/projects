Hi there, friend! So glad you found the time to play my new game:

'**You Are Definitely Bored At Home!**'

Or, more commonly known as:

'**Slapjack!**'

Playing my game is simple, and you will find the steps and instructions below.

Have fun!

1. Rules of the game:

    a. At the start of the game, you and the computer will be dealt half a deck

    b. To win, collect all the cards by being the first to slap each Jack

    c. Once your opponent runs out of cards, you win!

    d. To deal a card into the center press the 'Enter' button

    e. The computer will follow suit automatically

    f. Once a Jack is dealt, the competition between you and computer begins!

    g. **To SLAP, press the 's' button then the 'Enter' button**. Be fast!

    h. If you press just the 'Enter' button to slap, computer **wins** the round

    i. If you **SLAP** a Jack before the computer, you win the round 
    
    j. Winning the round means collecting the cards from the center

    k. If the computer SLAPS first, it wins the round

    l. If you **SLAP** on a card that's not a Jack, you will **BURN** your deck
    
    m. A **BURN** means placing your top card in the center deck

    n. **Have fun!**

2. To play my game, you need to run the program in your **Terminal** window

    a. Type this into the promt, <cd Downloads>

    b. Then type: <python MAIN_Slapjack.py>, and hit **Enter**

3. Once the game runs, you will see: "***Would you like to play the game of Slapjack?***"

    a. To exit the game, simply type anything but 'yes' and press 'Enter'

    b. Otherwise, be sure to type 'yes' and press 'Enter'

    c. Caplitalization does **NOT** matter

    d. If you typed 'yes', the game will launch in a separate graphics window

    e. You might have to move the window so you can see the **Terminal** window

    f. The **Terminal** window is where you will be interacting with the game
    
    g. See what is happening on the board on the **Graphics** window

4. Next, the game will ask you if "***Would you like to play in Easy or Hard mode?***"

    a. For Easy mode, be sure to type 'easy' and press 'Enter'

    b. For Hard mode, be sure to type 'hard' and press 'Enter'

    b. Caplitalization does **NOT** matter

    c. You can also unlock 'Expert' mode, but that is for you to figure out ;)

5. Once the difficulty is set, press the 'Enter' button to begin the game!

    a. Refer to the ***Rules of the game*** for how to play the game

6. Once the game is over, feel free to play as many times as you like by

    a. hitting the **UP arrow key** in your terminal window,

    b. and hitting **Enter**