import random

the_deck = [["Ace", "ace-of-hearts.gif", "Ace of Hearts"], ["2", "two-of-hearts.gif", '2 of Hearts'], \
["3", "three-of-hearts.gif", '3 of Hearts'], ["4", "four-of-hearts.gif", '4 of Hearts'], \
["5", "five-of-hearts.gif", '5 of Hearts'], ["6", "six-of-hearts.gif", '6 of Hearts'], \
["7", "seven-of-hearts.gif", '7 of Hearts'], ["8", "eight-of-hearts.gif", '8 of Hearts'], \
["9", "nine-of-hearts.gif", '9 of Hearts'], ["10", "ten-of-hearts.gif", '10 of Hearts'], \
["Jack", "jack-of-hearts.gif", 'Jack of Hearts'], ["Queen", "queen-of-hearts.gif", 'Queen of Hearts'], \
["King", "king-of-hearts.gif", 'King of Hearts'], ["Ace", "ace-of-spades.gif", 'Ace of Spades'], \
["2", "two-of-spades.gif", '2 of Spades'], ["3", "three-of-spades.gif", '3 of Spades'], \
["4", "four-of-spades.gif", '4 of Spades'], ["5", "five-of-spades.gif", '5 of Spades'], \
["6", "six-of-spades.gif", '6 of Spades'], ["7", "seven-of-spades.gif", '7 of Spades'], \
["8", "eight-of-spades.gif", '8 of Spades'], ["9", "nine-of-spades.gif", '9 of Spades'], \
["10", "ten-of-spades.gif", '10 of Spades'], ["Jack", "jack-of-spades.gif", 'Jack of Spades'], \
["Queen", "queen-of-spades.gif", 'Queen of Spades'], ["King", "king-of-spades.gif", 'King of Spades'], \
["Ace", "ace-of-diamonds.gif", 'Ace of Diamonds'], ["2", "two-of-diamonds.gif", '2 of Diamonds'], \
["3", "three-of-diamonds.gif", '3 of Diamonds'], ["4", "four-of-diamonds.gif", '4 of Diamonds'], \
["5", "five-of-diamonds.gif", '5 of Diamonds'], ["6", "six-of-diamonds.gif", '6 of Diamonds'], \
["7", "seven-of-diamonds.gif", '7 of Diamonds'], ["8", "eight-of-diamonds.gif", '8 of Diamonds'], \
["9", "nine-of-diamonds.gif", '9 of Diamonds'], ["10", "ten-of-diamonds.gif", '10 of Diamonds'], \
["Jack", "jack-of-diamonds.gif", 'Jack of Diamonds'], ["Queen", "queen-of-diamonds.gif", 'Queen of Diamonds'], \
["King", "king-of-diamonds.gif", 'King of Diamonds'], ["Ace", "ace-of-clubs.gif", 'Ace of Clubs'], \
["2", "two-of-clubs.gif", '2 of Clubs'], ["3", "three-of-clubs.gif", '3 of Clubs'], \
["4", "four-of-clubs.gif", '4 of Clubs'], ["5", "five-of-clubs.gif", '5 of Clubs'], \
["6", "six-of-clubs.gif", '6 of Clubs'], ["7", "seven-of-clubs.gif", '7 of Clubs'], \
["8", "eight-of-clubs.gif", '8 of Clubs'], ["9", "nine-of-clubs.gif", '9 of Clubs'], \
["10", "ten-of-clubs.gif", '10 of Clubs'], ["Jack", "jack-of-clubs.gif", 'Jack of Clubs'], \
["Queen", "queen-of-clubs.gif", 'Queen of Clubs'], ["King", "king-of-clubs.gif", 'King of Clubs']]

random.shuffle(the_deck)

def split_deck(deck):

    half = len(deck)//2

    return deck[:half], deck[half:]

partial_deck = the_deck

player_deck, computer_deck = split_deck(partial_deck)