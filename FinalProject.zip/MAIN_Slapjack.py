from slap_jack_deck import player_deck, computer_deck
import random, time, graphics, game_algorithm

user_input = input('Would you like to play the game of Slapjack?\nYes or No?\n')

user_input = user_input.lower()

if user_input == "yes":

    graphics.makeBoard()

    graphics.dealCards()

    game_algorithm.game_Flow()

else:

    print('No problemo, my friend. I hope to see you soon!\n')

    exit()
    
    