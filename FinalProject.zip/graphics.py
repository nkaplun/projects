import turtle
import time
from threading import Timer

'''
Author name: unknown
Date: unknown
Title of program/source code:  Blackjack with Card Graphics Remix
Web address or publisher: https://trinket.io/library/trinkets/7235ae2fc2

I used the above code to assist me with the makeBoard function.
All other functions are my own creations.
'''

def makeBoard():

    screen = turtle.Screen()
    screen.title('Slapjack')
    screen.bgcolor("white")

    thanos = turtle.Turtle()
    thanos.speed(0)

    thanos.goto(180,165)
    thanos.begin_fill()
    thanos.pendown()
    thanos.goto(180,-165)
    thanos.right(90)
    thanos.circle(-15,90)
    thanos.goto(-165,-180)
    thanos.circle(-15,90)
    thanos.goto(-180,165)
    thanos.circle(-15,90)
    thanos.goto(165,180)
    thanos.circle(-15,90)
    thanos.color('black')
    thanos.end_fill()
    
    thanos.penup()
    thanos.color("white")
    thanos.goto(165,160)
    thanos.pensize(3)
    thanos.begin_fill()
    thanos.pendown()
    thanos.goto(165,-160)
    thanos.circle(-5,90)
    thanos.goto(-160,-165)
    thanos.circle(-5,90)
    thanos.goto(-165,160)
    thanos.circle(-5,90)
    thanos.goto(160,165)
    thanos.circle(-5,90)
    thanos.color("maroon")
    thanos.end_fill()
    thanos.penup()
    thanos.goto(0,0)

def dealCards():
    screen = turtle.Screen()
    screen.addshape("card-back.gif")

    playerDeck = turtle.Turtle()
    playerDeck.penup()
    playerDeck.setheading(270)
    playerDeck.shape("card-back.gif")
    playerDeck.forward(100)
    playerDeck.pendown

    computerDeck = turtle.Turtle()
    computerDeck.penup()
    computerDeck.setheading(90)
    computerDeck.shape("card-back.gif")
    computerDeck.forward(100)
    computerDeck.pendown

def player_cardDisplay(image):

    screen = turtle.Screen()
    screen.addshape(image)

    centerDeck = turtle.Turtle()
    centerDeck.hideturtle()
    centerDeck.penup()
    centerDeck.speed(6)
    centerDeck.goto(0, -100)
    centerDeck.showturtle()
    centerDeck.shape(image)
    centerDeck.showturtle()
    centerDeck.setheading(90)
    centerDeck.forward(100)
    
def computer_cardDisplay(image):

    screen = turtle.Screen()
    screen.addshape(image)

    centerDeck = turtle.Turtle()
    centerDeck.hideturtle()
    centerDeck.penup()
    centerDeck.speed(6)
    centerDeck.goto(0, 100)
    centerDeck.shape(image)
    centerDeck.showturtle()
    centerDeck.setheading(270)
    centerDeck.forward(100)

def slap_burnDisplay(image):
    
    screen = turtle.Screen()
    screen.addshape(image)

    centerDeck = turtle.Turtle()
    centerDeck.home()
    centerDeck.speed(1)
    centerDeck.pendown()
    centerDeck.shape(image)

    input()

    centerDeck.hideturtle()

def collectDeck(image, bg_image, direction):

    screen = turtle.Screen()
    screen.addshape(image)
    screen.addshape(bg_image)

    another_image = turtle.Turtle()
    another_image.penup()
    another_image.speed(0)
    another_image.home()
    another_image.shape(bg_image)

    centerDeck = turtle.Turtle()
    centerDeck.penup()
    centerDeck.speed(1)
    centerDeck.home()
    centerDeck.shape(image)
    centerDeck.setheading(direction)
    centerDeck.forward(100)
    centerDeck.hideturtle()

def the_outcome(image, another_image, x, y):

    screen = turtle.Screen()
    screen.addshape(image)
    screen.addshape(another_image)

    anotherDeck = turtle.Turtle()
    anotherDeck.hideturtle()
    anotherDeck.penup()
    anotherDeck.goto(x, y)
    anotherDeck.shape(another_image)
    anotherDeck.showturtle()

    centerDeck = turtle.Turtle()
    centerDeck.home()
    centerDeck.speed(1)
    centerDeck.pendown()
    centerDeck.shape(image)

def burn_cardDisplay(image):

    screen = turtle.Screen()
    screen.addshape(image)

    centerDeck = turtle.Turtle()
    centerDeck.hideturtle()
    centerDeck.penup()
    centerDeck.speed(1)
    centerDeck.goto(0, -100)
    centerDeck.showturtle()
    centerDeck.shape(image)
    centerDeck.showturtle()
    centerDeck.setheading(90)
    centerDeck.forward(100)